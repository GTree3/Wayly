const ORS_API_KEY = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjFiYTEyMGNiNTI1MDQ4M2M4MDRkNzk3YWMwM2M4OGU3IiwiaCI6Im11cm11cjY0In0=";

// ============================
// Popup helpers
// ============================

function escapeHtml(str) {
  if (!str) return "";
  return String(str).replace(/[&<>"']/g, (m) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[m]));
}

function buildWashroomPopup(props) {
  const types = [];
  if (props.women) types.push("Women");
  if (props.men) types.push("Men");
  if (props.unisex) types.push("Universal");

  const wheelchair = props.wheelchair
    ? "✅ Wheelchair accessible"
    : "❌ Not wheelchair accessible";

  const baby = props.baby_change
    ? "✅ Baby changing station"
    : "❌ No baby changing station";

  const notes = props.notes
    ? `<div style="margin-top:6px;"><b>Notes:</b><br>${escapeHtml(props.notes)}</div>`
    : "";

  return `
    <div style="min-width:220px;">
      <div style="font-weight:700; font-size:14px; margin-bottom:6px;">
        ${escapeHtml(props.name || "Washroom")}
      </div>

      <div><b>Type:</b> ${types.length ? types.join(" / ") : "Unknown"}</div>
      <div style="margin-top:4px;">${wheelchair}</div>
      <div>${baby}</div>

      ${notes}
    </div>
  `;
}


// 2. Initialize Leaflet Map
const map = L.map("map", {
  zoomControl: false
}).setView([43.6532, -79.3832], 11);

// Add zoom control LOWER on the left
L.control.zoom({ position: "topleft" }).addTo(map);

L.tileLayer(
  "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
  {
    attribution: "&copy; OpenStreetMap contributors"
  }
).addTo(map);

// =======================================
// 3. Get User Location
// =======================================

let userCoords = null;

navigator.geolocation.getCurrentPosition(
  (position) => {
    userCoords = [
      position.coords.latitude,
      position.coords.longitude
    ];

    L.marker(userCoords)
      .addTo(map)
      .bindPopup("You are here")
      .openPopup();

    map.setView(userCoords, 12);

    loadWashrooms();
  },
  () => {
    alert("Please allow location access for the demo.");
  },
  { enableHighAccuracy: true }
);

// =======================================
// 4. Load Washrooms + Find Closest
// =======================================

async function loadWashrooms() {
  const response = await fetch("washrooms.geojson");
  const geojson = await response.json();

  let closestWashroom = null;
  let minDistance = Infinity;

  geojson.features.forEach((feature) => {
    const [lng, lat] = feature.geometry.coordinates;

    const distance = map.distance(userCoords, [lat, lng]);

    if (distance < minDistance) {
      minDistance = distance;
      closestWashroom = feature;
    }

    const props = feature.properties || {};

    L.marker([lat, lng])
      .addTo(map)
      .bindPopup(buildWashroomPopup(props));

  });

  if (closestWashroom) {
    routeToWashroom(closestWashroom);
  }
}

// =======================================
// 5. Route to Closest Washroom (ORS)
// =======================================

async function routeToWashroom(feature) {
  const [destLng, destLat] = feature.geometry.coordinates;

  const body = {
    coordinates: [
      [userCoords[1], userCoords[0]],
      [destLng, destLat]
    ]
  };

  const response = await fetch(
    "https://api.openrouteservice.org/v2/directions/foot-walking/geojson",
    {
      method: "POST",
      headers: {
        "Authorization": ORS_API_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    }
  );

  const routeGeoJSON = await response.json();

  L.geoJSON(routeGeoJSON, {
    style: {
      color: "#2563eb",
      weight: 5
    }
  }).addTo(map);

  // Center map between user and destination (simple, stable demo behavior)
  const centerLat = (userCoords[0] + destLat) / 2;
  const centerLng = (userCoords[1] + destLng) / 2;

  // Optional: adjust zoom a bit based on distance
  const straightLineMeters = map.distance(userCoords, [destLat, destLng]);
  const zoom = straightLineMeters > 700 ? 11 : 12;

  map.setView([centerLat, centerLng], zoom);

}
